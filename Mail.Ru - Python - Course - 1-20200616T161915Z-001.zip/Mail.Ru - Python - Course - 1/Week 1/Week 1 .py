from mymodule import multiply as mp

dir(mp)

import dis

dis.dis(mp)